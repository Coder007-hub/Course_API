package com.smallproject.CourseApi.topics;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class topicservice {
    
   List<topic> topics= Arrays.asList(
            new topic("Java", "String2", "String3"),
            new topic("Maths", "String2", "String3"),
            new topic("Physics", "String2", "String3")
        );

        public List<topic> getAllTopics(){

            return topics;
        }

        public topic geTopic(String id)

        {
          return  topics.stream().filter(t -> t.getId().equals(id)).findFirst().get();
        }
}
