package com.smallproject.CourseApi.topics;

public class topic {
    
    private String Id;
    private String name;
    private String discription;

    public topic()
    {
        
    }
    
    public topic(String id, String name, String discription) {
        Id = id;
        this.name = name;
        this.discription = discription;
    }
    public String getId() {
        return Id;
    }
    public void setId(String id) {
        Id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDiscription() {
        return discription;
    }
    public void setDiscription(String discription) {
        this.discription = discription;
    }
    

}
