package com.smallproject.CourseApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class universityApplication {

	public static void main(String[] args) {
		SpringApplication.run(universityApplication.class, args);
		
	}

}
