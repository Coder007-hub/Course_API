package com.smallproject.CourseApi.hellocontroller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;


@RestController
public class hellocontroller {

    @RequestMapping("/hello")
    public String sayHi()
    {
        return "HI RETURN";
    }
    
}
